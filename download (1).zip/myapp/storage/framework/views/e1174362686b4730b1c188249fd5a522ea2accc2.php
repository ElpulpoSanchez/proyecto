<?php $__env->startSection('content'); ?>

<h1>
  Listado de usuarios
</h1>
<div class="row">
  <div class="col-md-12">
    
  </div>
</div>

<div class="row">
  <div class="col-md-12">
    
    <table class="table">
      <thead>
      <tr>
        <th class="text-center">Nombre</th>
        <th class="text-center">Correo</th>
        </tr>
      </thead>
  <tbody>
    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td>
      <a href="<?php echo e(action('userController@show'.$usuario->id)); ?>"
      </td>
    <td><?php echo e($usuario -> name); ?></td>
    <td><?php echo e($Correo -> email); ?></td>  
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody> 
    </table>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>