@extends('layouts.app')
@section('content')

<h1>
  Listado de usuarios
</h1>
<div class="row">
  <div class="col-md-12">
    
  </div>
</div>

<div class="row">
  <div class="col-md-12">
    
    <table class="table">
      <thead>
      <tr>
        <th class="text-center">Nombre</th>
        <th class="text-center">Correo</th>
        <th class="text-center">Fecha de creacion</th>
        </tr>
      </thead>
  <tbody>
    <tr>
      <td>
      <a href="{{action('userController@show'.$usuario->id)}}"
      </td>
    <td>{{ $user-> name}}</td>
    <td>{{ $user-> email}}</td> 
    <td>{{ $user-> create_at}}</td>  
    </tr>
      </tbody> 
    </table>
  </div>
</div>

@endsection