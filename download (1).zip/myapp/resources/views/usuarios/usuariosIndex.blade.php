@extends('layouts.app')
@section('content')

<h1>
  Listado de usuarios
</h1>
<div class="row">
  <div class="col-md-12">
    
  </div>
</div>

<div class="row">
  <div class="col-md-12">
    
    <table class="table">
      <thead>
      <tr>
        <th class="text-center">Nombre</th>
        <th class="text-center">Correo</th>
        </tr>
      </thead>
  <tbody>
    @foreach($usuarios as $usuario)
    <tr>
      <td>
      <a href="{{action('userController@show'.$usuario->id)}}"
      </td>
    <td>{{$usuario -> name}}</td>
    <td>{{$Correo -> email}}</td>  
    </tr>
    @endforeach
      </tbody> 
    </table>
  </div>
</div>

@endsection