@extends('layouts.app')
@section('content')

<h1>
  Capturar nuevo usuario
</h1>
<div class="row">
  <div class="col-md-12">
    
  </div>
</div>

<div class="row">
 <div class="col-md-10">
   <form>
     <form action="{{ action('UserController@store') }}" method="POST">
      
     <div class="form-group">
     <label for="name">Nombre</label>
     <input type="text" name="name" placeholder "Nombre del usuario" class="form-control" required>
     </div>
     <div class="form-group">  
     <label for="email">Correo</label>
     <input type="email" email="email" placeholder "Correo" class="form-control">
     </div>
     <div class="form-group">
     <label for="password">Contraseña</label>
     <input type="password" password="password" placeholder "contraseña" class="form-control">
     </div>
       <div class="form-group">
     <label for="password_confirmation">Contraseña</label>
     <input type="password" password="password_confirmation" placeholder "contraseña" class="form-control">
     </div>
     
   </form>
  </div>  
</div>